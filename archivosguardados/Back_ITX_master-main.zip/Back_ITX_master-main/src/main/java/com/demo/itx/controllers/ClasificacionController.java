package com.demo.itx.controllers;

import com.demo.itx.models.Clasificacion;
import com.demo.itx.repositories.DAOImplClasificacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/clasificacion")
public class ClasificacionController {
    @Autowired
    DAOImplClasificacion daoImpClasificacion;

    @GetMapping("/Clasificacions")
    public ResponseEntity<List<Clasificacion>> getClasificacionos() {

        List<Clasificacion> clasificacion = daoImpClasificacion.listar();
        return new ResponseEntity<>(clasificacion, HttpStatus.OK);
    }

    @PostMapping("/clasificacion")
    @ResponseBody
    public Clasificacion postClasificaciono(@RequestBody Clasificacion clasificacion) {
        // Proveedor proveedor = proveedorRepositorio.findById(id).get();
        // clasificacion.setUsuario(usuario);
        return daoImpClasificacion.crear(clasificacion);
    }

    @PutMapping("/clasificacion/{id}")
    @ResponseBody
    public Clasificacion updateClasificacion(@RequestBody Clasificacion clasificacion, @PathVariable Long id) {
        clasificacion.setId_clasificacion(id);
        return daoImpClasificacion.crear(clasificacion);
    }

    @GetMapping("/clasificacion/{id}")
    public Optional<Clasificacion> getClasificacionoById(@PathVariable("id") long id)  {

        return daoImpClasificacion.porId(id);

    }



    @DeleteMapping("/clasificacion/{id}")
    ResponseEntity<?> deleteClasificacion(@PathVariable Long id) {
        daoImpClasificacion.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
