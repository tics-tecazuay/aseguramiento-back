package com.demo.itx.controllers;

import com.demo.itx.models.Foto;
import com.demo.itx.repositories.DAOImplFoto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/foto")
public class FotoController {
    @Autowired
    DAOImplFoto daoImpFoto;

    @GetMapping("/fotos")
    public ResponseEntity<List<Foto>> getFotoos() {

        List<Foto> foto = daoImpFoto.listar();
        return new ResponseEntity<>(foto, HttpStatus.OK);
    }

    @PostMapping("/foto")
    @ResponseBody
    public Foto postFotoo(@RequestBody Foto foto) {
        // Proveedor proveedor = proveedorRepositorio.findById(id).get();
        // foto.setUsuario(usuario);
        return daoImpFoto.crear(foto);
    }

    @PutMapping("/foto/{id}")
    @ResponseBody
    public Foto updateFoto(@RequestBody Foto foto, @PathVariable Long id) {
        foto.setId_foto(id);
        return daoImpFoto.crear(foto);
    }

    @GetMapping("/foto/{id}")
    public Optional<Foto> getFotooById(@PathVariable("id") long id)  {

        return daoImpFoto.porId(id);

    }



    @DeleteMapping("/foto/{id}")
    ResponseEntity<?> deleteFoto(@PathVariable Long id) {
        daoImpFoto.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
