package com.demo.itx.controllers;

import com.demo.itx.models.Gasto;
import com.demo.itx.repositories.DAOImplGasto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/gasto")
public class GastoController {
    @Autowired
    DAOImplGasto daoImpGasto;

    @GetMapping("/gastos")
    public ResponseEntity<List<Gasto>> getGastoos() {

        List<Gasto> gasto = daoImpGasto.listar();
        return new ResponseEntity<>(gasto, HttpStatus.OK);
    }

    @PostMapping("/gasto")
    @ResponseBody
    public Gasto postGastoo(@RequestBody Gasto gasto) {
        // Proveedor proveedor = proveedorRepositorio.findById(id).get();
        // gasto.setUsuario(usuario);
        return daoImpGasto.crear(gasto);
    }

    @PutMapping("/gasto/{id}")
    @ResponseBody
    public Gasto updateGasto(@RequestBody Gasto gasto, @PathVariable Long id) {
        gasto.setId_gasto(id);
        return daoImpGasto.crear(gasto);
    }

    @GetMapping("/gasto/{id}")
    public Optional<Gasto> getGastooById(@PathVariable("id") long id)  {

        return daoImpGasto.porId(id);

    }



    @DeleteMapping("/gasto/{id}")
    ResponseEntity<?> deleteGasto(@PathVariable Long id) {
        daoImpGasto.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
