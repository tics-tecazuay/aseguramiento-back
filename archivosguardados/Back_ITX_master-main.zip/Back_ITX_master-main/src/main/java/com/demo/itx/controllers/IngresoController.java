package com.demo.itx.controllers;

import com.demo.itx.models.Ingreso;
import com.demo.itx.repositories.DAOImplIngreso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/ingreso")
public class IngresoController {
    @Autowired
    DAOImplIngreso daoImpIngreso;

    @GetMapping("/ingresos")
    public ResponseEntity<List<Ingreso>> getIngresoos() {

        List<Ingreso> ingreso = daoImpIngreso.listar();
        return new ResponseEntity<>(ingreso, HttpStatus.OK);
    }

    @PostMapping("/ingreso")
    @ResponseBody
    public Ingreso postIngresoo(@RequestBody Ingreso ingreso) {
        // Proveedor proveedor = proveedorRepositorio.findById(id).get();
        // ingreso.setUsuario(usuario);
        return daoImpIngreso.crear(ingreso);
    }

    @PutMapping("/ingreso/{id}")
    @ResponseBody
    public Ingreso updateIngreso(@RequestBody Ingreso ingreso, @PathVariable Long id) {
        ingreso.setId_ingreso(id);
        return daoImpIngreso.crear(ingreso);
    }

    @GetMapping("/ingreso/{id}")
    public Optional<Ingreso> getIngresooById(@PathVariable("id") long id)  {

        return daoImpIngreso.porId(id);

    }



    @DeleteMapping("/ingreso/{id}")
    ResponseEntity<?> deleteIngreso(@PathVariable Long id) {
        daoImpIngreso.eliminar(id);
        return ResponseEntity.noContent().build();
    }

}
