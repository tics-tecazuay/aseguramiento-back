package com.demo.itx.models;

import javax.persistence.*;
import java.io.Serializable;
@Entity
public class Clasificacion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_clasificacion;
    private String nombre;
    private String descripcion;
    @ManyToOne
    private Foto foto;

    public Long getId_clasificacion() {
        return id_clasificacion;
    }

    public void setId_clasificacion(Long id_clasificacion) {
        this.id_clasificacion = id_clasificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Foto getFoto() {
        return foto;
    }

    public void setFoto(Foto foto) {
        this.foto = foto;
    }
}
