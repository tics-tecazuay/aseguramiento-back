package com.demo.itx.models;

import javax.persistence.*;
import java.io.Serializable;
@Entity
public class Foto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_foto;

    @Column(name = "data")
    private byte[] data;

    public Long getId_foto() {
        return id_foto;
    }

    public void setId_foto(Long id_foto) {
        this.id_foto = id_foto;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
