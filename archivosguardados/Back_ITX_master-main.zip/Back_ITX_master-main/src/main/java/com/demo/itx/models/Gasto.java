package com.demo.itx.models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
@Entity
public class Gasto implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_gasto;

    private int cantidad;
    private String descripcion;
    private Date fecha;
    @ManyToOne
    private Empresa empresa;
    @ManyToOne
    private Clasificacion clasificacion;

    public Long getId_gasto() {
        return id_gasto;
    }

    public void setId_gasto(Long id_gasto) {
        this.id_gasto = id_gasto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Clasificacion getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(Clasificacion clasificacion) {
        this.clasificacion = clasificacion;
    }
}
