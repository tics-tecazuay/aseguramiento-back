package com.demo.itx.models;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
public class Ingreso implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_ingreso;
    private int cantidad;
    private String descripcion;
    private Date Fecha;
    @ManyToOne
    private Empresa empresa;
    @ManyToOne
    private Clasificacion clasificacion;


    public Long getId_ingreso() {
        return id_ingreso;
    }

    public void setId_ingreso(Long id_ingreso) {
        this.id_ingreso = id_ingreso;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        Fecha = fecha;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Clasificacion getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(Clasificacion clasificacion) {
        this.clasificacion = clasificacion;
    }
}
