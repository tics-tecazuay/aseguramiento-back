package com.demo.itx.repositories;

import com.demo.itx.models.Clasificacion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public class DAOImplClasificacion implements IDAOClasificacion{

    @Autowired
    private IRepositoryClasificacion repository;

    @Override
    public Clasificacion crear(Clasificacion clasificacion) {

        return repository.save(clasificacion);
    }

    @Override
    public Optional<Clasificacion> porId(Long idClasificacion) {

        return repository.findById(idClasificacion);
    }

    @Override
    public List<Clasificacion> listar() {

        return repository.findAll();
    }

    @Override
    public Clasificacion actualizar(Clasificacion clasificacion, Long idClasificacion) {

        if (repository.findById(idClasificacion)!=null) {
            clasificacion.setId_clasificacion(idClasificacion);
            return repository.save(clasificacion);
        }else {
            return null;
        }
    }

    @Override
    public boolean eliminar(Long idClasificacion) {

        if(repository.findById(idClasificacion)!=null) {
            repository.deleteById(idClasificacion);
            return true;
        }else {
            return false;
        }
    }
}
