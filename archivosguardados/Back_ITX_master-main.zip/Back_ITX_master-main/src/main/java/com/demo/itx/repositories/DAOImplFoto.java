package com.demo.itx.repositories;

import com.demo.itx.models.Foto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DAOImplFoto implements IDAOFoto{

    @Autowired
    private IRepositoryFoto repository;

    @Override
    public Foto crear(Foto foto) {

        return repository.save(foto);
    }

    @Override
    public Optional<Foto> porId(Long idFoto) {

        return repository.findById(idFoto);
    }

    @Override
    public List<Foto> listar() {

        return repository.findAll();
    }

    @Override
    public Foto actualizar(Foto foto, Long idFoto) {

        if (repository.findById(idFoto)!=null) {
            foto.setId_foto(idFoto);
            return repository.save(foto);
        }else {
            return null;
        }
    }

    @Override
    public boolean eliminar(Long idFoto) {

        if(repository.findById(idFoto)!=null) {
            repository.deleteById(idFoto);
            return true;
        }else {
            return false;
        }
    }
}
