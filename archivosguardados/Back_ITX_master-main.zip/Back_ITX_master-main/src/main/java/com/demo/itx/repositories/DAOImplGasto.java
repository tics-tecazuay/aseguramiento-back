package com.demo.itx.repositories;

import com.demo.itx.models.Gasto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public class DAOImplGasto implements IDAOGasto{

    @Autowired
    private IRepositoryGasto repository;

    @Override
    public Gasto crear(Gasto gasto) {

        return repository.save(gasto);
    }

    @Override
    public Optional<Gasto> porId(Long idGasto) {

        return repository.findById(idGasto);
    }

    @Override
    public List<Gasto> listar() {

        return repository.findAll();
    }

    @Override
    public Gasto actualizar(Gasto gasto, Long idGasto) {

        if (repository.findById(idGasto)!=null) {
            gasto.setId_gasto(idGasto);
            return repository.save(gasto);
        }else {
            return null;
        }
    }

    @Override
    public boolean eliminar(Long idGasto) {

        if(repository.findById(idGasto)!=null) {
            repository.deleteById(idGasto);
            return true;
        }else {
            return false;
        }
    }
}
