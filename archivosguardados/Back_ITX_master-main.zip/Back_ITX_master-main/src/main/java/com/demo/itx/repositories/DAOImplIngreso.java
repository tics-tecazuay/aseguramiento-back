package com.demo.itx.repositories;

import com.demo.itx.models.Ingreso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DAOImplIngreso implements IDAOIngreso{

    @Autowired
    private IRepositoryIngreso repository;

    @Override
    public Ingreso crear(Ingreso ingreso) {

        return repository.save(ingreso);
    }

    @Override
    public Optional<Ingreso> porId(Long idIngreso) {

        return repository.findById(idIngreso);
    }

    @Override
    public List<Ingreso> listar() {

        return repository.findAll();
    }

    @Override
    public Ingreso actualizar(Ingreso ingreso, Long idIngreso) {

        if (repository.findById(idIngreso)!=null) {
            ingreso.setId_ingreso(idIngreso);
            return repository.save(ingreso);
        }else {
            return null;
        }
    }

    @Override
    public boolean eliminar(Long idIngreso) {

        if(repository.findById(idIngreso)!=null) {
            repository.deleteById(idIngreso);
            return true;
        }else {
            return false;
        }
    }
}
