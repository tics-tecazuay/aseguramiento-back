package com.demo.itx.repositories;

import com.demo.itx.models.Clasificacion;

import java.util.List;
import java.util.Optional;

public interface IDAOClasificacion {
    Clasificacion crear(Clasificacion clasificacion);

    Optional<Clasificacion> porId(Long idClasificacion);

    List<Clasificacion> listar();

    Clasificacion actualizar(Clasificacion clasificacion, Long idClasificacion);

    boolean eliminar(Long idClasificacion);
}
