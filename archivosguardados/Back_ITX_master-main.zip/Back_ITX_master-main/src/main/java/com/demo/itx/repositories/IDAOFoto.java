package com.demo.itx.repositories;

import com.demo.itx.models.Foto;

import java.util.List;
import java.util.Optional;

public interface IDAOFoto {
    Foto crear(Foto foto);

    Optional<Foto> porId(Long idFoto);

    List<Foto> listar();

    Foto actualizar(Foto foto, Long idFoto);

    boolean eliminar(Long idFoto);
}
