package com.demo.itx.repositories;

import com.demo.itx.models.Gasto;

import java.util.List;
import java.util.Optional;

public interface IDAOGasto {
    Gasto crear(Gasto gasto);

    Optional<Gasto> porId(Long idGasto);

    List<Gasto> listar();

    Gasto actualizar(Gasto gasto, Long idGasto);

    boolean eliminar(Long idGasto);
}
