package com.demo.itx.repositories;

import com.demo.itx.models.Ingreso;

import java.util.List;
import java.util.Optional;

public interface IDAOIngreso {

    Ingreso crear(Ingreso ingreso);

    Optional<Ingreso> porId(Long idIngreso);

    List<Ingreso> listar();

    Ingreso actualizar(Ingreso ingreso, Long idIngreso);

    boolean eliminar(Long idIngreso);
    
}
