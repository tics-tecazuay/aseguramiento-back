package com.demo.itx.repositories;

import com.demo.itx.models.Cargo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositoryCargo extends JpaRepository<Cargo, Long>{

}
