package com.demo.itx.repositories;

import com.demo.itx.models.Foto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositoryFoto extends JpaRepository<Foto, Long> {
}
