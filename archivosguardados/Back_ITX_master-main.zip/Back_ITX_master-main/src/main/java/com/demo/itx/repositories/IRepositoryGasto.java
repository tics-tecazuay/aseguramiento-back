package com.demo.itx.repositories;

import com.demo.itx.models.Gasto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositoryGasto extends JpaRepository<Gasto, Long> {
}
