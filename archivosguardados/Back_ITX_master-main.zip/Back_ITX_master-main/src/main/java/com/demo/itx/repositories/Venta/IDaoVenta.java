package com.demo.itx.repositories.Venta;

public interface IDaoVenta {

}
