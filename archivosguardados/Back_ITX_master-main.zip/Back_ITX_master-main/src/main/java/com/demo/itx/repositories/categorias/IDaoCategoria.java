package com.demo.itx.repositories.categorias;

public class IDaoCategoria {
	
}
